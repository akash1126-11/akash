import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, mean_squared_error
import pickle
import datetime

# Set Streamlit page configuration
st.set_page_config(
    page_title="Stock Market Analysis Dashboard",
    layout="wide"
)

st.title("Stock Market Analysis Dashboard")

st.markdown("""
# Stock Market Analysis (2013–2018)
## Dataset Overview
The dataset is `all_stocks_5yr.csv`, containing information on 505 unique stock tickers from February 8, 2013, to February 7, 2018.
Total records: 619,040.

## Key Insights
* **Most Frequently Traded Stocks (by entries):** AAL, NRG, NOC, NLSN, NKE.
* **Most Actively Traded Stocks (by average daily volume):** BAC, AAPL, GE, F, FB.
* **Technical Highlights**: This dashboard uses data from the 2013-2018 period for analysis and to predict future trends.
""")

# --- Data Loading Section ---
st.header("Upload your Stock Data (2013-2018)")
uploaded_file = st.file_uploader("Choose a CSV file (e.g., all_stocks_5yr.csv)", type="csv")
data_df = pd.DataFrame()

if uploaded_file is not None:
    data_df = pd.read_csv(uploaded_file, header=None, names=['date', 'open', 'high', 'low', 'close', 'volume', 'Name'], skiprows=1)
    st.success("File uploaded and loaded successfully!")
else:
    st.info("Please upload a CSV file with data from 2013-2018 to proceed. A placeholder dataset is used for demonstration.")
    # Create a placeholder DataFrame for demonstration if no file is uploaded
    try:
        data_df = pd.DataFrame({
            'date': pd.to_datetime(pd.date_range(start='2013-02-08', periods=20, freq='D').repeat(5)),
            'open': np.random.rand(100) * 100,
            'high': np.random.rand(100) * 100,
            'low': np.random.rand(100) * 100,
            'close': np.random.rand(100) * 100,
            'volume': np.random.randint(1000000, 50000000, size=100),
            'Name': ['AAPL'] * 20 + ['GOOG'] * 20 + ['AMZN'] * 20 + ['MSFT'] * 20 + ['FB'] * 20
        })
    except Exception as e:
        st.error(f"Error creating placeholder data: {e}")
        st.stop()


if not data_df.empty:
    # --- Data Cleaning and Preprocessing ---
    st.subheader("Data Preprocessing")
    data_df.columns = ['date', 'open', 'high', 'low', 'close', 'volume', 'Name']
    data_df['date'] = pd.to_datetime(data_df['date'])
    data_df.fillna(0, inplace=True)
    st.write("Data successfully loaded and cleaned.")

    st.subheader("Data Snapshot")
    st.write(data_df.head())
    st.write("Dataset Shape:", data_df.shape)

    # --- Interactive Widgets for Visualization ---
    st.sidebar.header("Filter Options")
    all_companies = data_df['Name'].unique().tolist()
    selected_company = st.sidebar.selectbox('Select a Company', all_companies, index=0)

    # Date range selector
    min_date = data_df['date'].min()
    max_date = data_df['date'].max()
    date_range = st.sidebar.slider(
        "Select Date Range",
        value=(min_date.to_pydatetime(), max_date.to_pydatetime())
    )

    # Filter DataFrame based on user selections
    filtered_df = data_df[data_df['Name'] == selected_company]
    filtered_df = filtered_df[(filtered_df['date'] >= date_range[0]) & (filtered_df['date'] <= date_range[1])]

    # --- Visualizations ---
    st.header("Visualizations")
    
    # Stock Price Trend
    st.subheader(f"Stock Price Trend for {selected_company}")
    fig, ax = plt.subplots(figsize=(14, 6))
    ax.plot(filtered_df['date'], filtered_df['close'], label='Close Price')
    ax.set_title(f'{selected_company} Closing Price Over Time')
    ax.set_xlabel('Date')
    ax.set_ylabel('Close Price')
    ax.grid(True)
    ax.legend()
    st.pyplot(fig)

    # Distribution of Daily Closing Prices
    st.subheader("Distribution of Daily Closing Prices (All Companies)")
    fig2, ax2 = plt.subplots(figsize=(12, 6))
    sns.histplot(data_df['close'], bins=100, kde=True, color='skyblue', ax=ax2)
    ax2.set_title('Distribution of Daily Closing Prices')
    ax2.set_xlabel('Closing Price (USD)')
    ax2.set_ylabel('Frequency')
    st.pyplot(fig2)

    # Top 5 Stocks by Total Volume
    st.subheader("Top 5 Stocks by Total Volume")
    top_volume = data_df.groupby('Name')['volume'].sum().nlargest(5)
    fig3, ax3 = plt.subplots(figsize=(14, 6))
    sns.barplot(x=top_volume.index, y=top_volume.values, palette='viridis', ax=ax3)
    ax3.set_title('Top 5 Stocks by Total Volume')
    ax3.set_xlabel('Stock Symbol')
    ax3.set_ylabel('Total Volume')
    st.pyplot(fig3)

    # AMZN High vs Low Prices
    st.subheader("AMZN Daily High vs Low Prices (5 Years)")
    amzn_df = data_df[data_df['Name'] == 'AMZN']
    if not amzn_df.empty:
        fig4, ax4 = plt.subplots(figsize=(14, 6))
        ax4.plot(amzn_df['date'], amzn_df['high'], label='High Price', color='green', alpha=0.6)
        ax4.plot(amzn_df['date'], amzn_df['low'], label='Low Price', color='red', alpha=0.6)
        ax4.fill_between(amzn_df['date'], amzn_df['low'], amzn_df['high'], color='gray', alpha=0.2)
        ax4.set_title('AMZN Daily High vs Low Prices (5 Years)')
        ax4.set_xlabel('Date')
        ax4.set_ylabel('Price (USD)')
        ax4.legend()
        ax4.grid(True)
        st.pyplot(fig4)
    else:
        st.warning("No data for AMZN found.")

    # FB Daily Returns
    st.subheader("FB Daily Returns (2013–2018)")
    fb_df = data_df[data_df['Name'] == 'FB'].copy()
    if not fb_df.empty:
        fb_df['daily_return'] = fb_df['close'].pct_change()
        fig5, ax5 = plt.subplots(figsize=(14, 6))
        ax5.plot(fb_df['date'], fb_df['daily_return'], label='FB Daily Return', color='orange')
        ax5.set_title('FB Daily Returns (2013–2018)', fontsize=16)
        ax5.set_xlabel('Date')
        ax5.set_ylabel('Daily Return')
        ax5.axhline(0, color='black', linestyle='--', linewidth=0.7)
        ax5.grid(True, linestyle='--', alpha=0.5)
        ax5.legend()
        st.pyplot(fig5)
    else:
        st.warning("No data for FB found.")


    # Correlation Matrix
    st.subheader("Correlation of Average Stock Metrics Across All Companies")
    company_avg = data_df.groupby("Name")[["open", "high", "low", "close", "volume"]].mean()
    correlation_matrix = company_avg.corr()
    fig6, ax6 = plt.subplots(figsize=(8, 6))
    sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm", fmt=".2f", ax=ax6)
    ax6.set_title("Correlation of Average Stock Metrics")
    st.pyplot(fig6)

    # Volatility Analysis
    st.subheader("Top 10 Most Volatile Stocks")
    data_df['daily_return'] = data_df.groupby('Name')['close'].pct_change()
    volatility = data_df.groupby('Name')['daily_return'].std().sort_values(ascending=False)
    top_10_volatile = volatility.head(10).reset_index()
    top_10_volatile.columns = ['Stock', 'Volatility']
    fig7, ax7 = plt.subplots(figsize=(12, 6))
    sns.barplot(x='Stock', y='Volatility', data=top_10_volatile, ax=ax7)
    ax7.set_title("Top 10 Most Volatile Stocks (Based on Daily Returns)")
    ax7.set_xlabel("Stock")
    ax7.set_ylabel("Volatility (Standard Deviation of Daily Returns)")
    st.pyplot(fig7)


    # --- Machine Learning Section ---
    st.header("Machine Learning Prediction")
    st.markdown("""
    This section trains a machine learning model to predict future stock price movement.
    """)

    # Select a stock for ML analysis
    stock_for_ml = st.selectbox("Select a stock for ML analysis", all_companies, index=0)

    # Data preparation for ML model
    stock_df = data_df[data_df['Name'] == stock_for_ml].copy()
    stock_df.sort_values('date', inplace=True)
    stock_df['prev_close'] = stock_df['close'].shift(1)
    stock_df['daily_return_pct'] = (stock_df['close'] - stock_df['prev_close']) / stock_df['prev_close']
    stock_df['rolling_mean_5'] = stock_df['close'].rolling(5).mean()
    stock_df['rolling_std_5'] = stock_df['close'].rolling(5).std()
    stock_df['volume_change'] = stock_df['volume'].pct_change()
    stock_df['high_low_ratio'] = stock_df['high'] / stock_df['low']
    stock_df['close_open_ratio'] = stock_df['close'] / stock_df['open']
    for i in range(1, 4):
        stock_df[f'lag_{i}'] = stock_df['close'].shift(i)
    stock_df['target'] = (stock_df['close'].shift(-1) > stock_df['close']).astype(int)
    stock_df.dropna(inplace=True)

    st.write(f"Engineered Features for {stock_for_ml}:")
    st.write(stock_df.head())

    # --- XGBoost Model Training and Evaluation ---
    st.subheader(f"XGBoost Model Performance for {stock_for_ml}")
    
    if not stock_df.empty:
        # Define features and target
        features = stock_df.drop(['date', 'Name', 'target'], axis=1).columns
        X = stock_df[features]
        y = stock_df['target']

        # Split data into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Train the XGBoost model
        model = XGBClassifier(use_label_encoder=False, eval_metric='logloss')
        model.fit(X_train, y_train)

        # Make predictions
        y_pred = model.predict(X_test)
        
        # Display performance metrics
        accuracy = accuracy_score(y_test, y_pred)
        st.write(f"**Model Accuracy:** {accuracy:.4f}")
        
        st.write("**Classification Report:**")
        st.text(classification_report(y_test, y_pred))
        
        st.write("**Confusion Matrix:**")
        cm = confusion_matrix(y_test, y_pred)
        fig_cm, ax_cm = plt.subplots(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax_cm)
        ax_cm.set_title('Confusion Matrix')
        ax_cm.set_xlabel('Predicted')
        ax_cm.set_ylabel('Actual')
        st.pyplot(fig_cm)
    else:
        st.warning(f"Not enough data for {stock_for_ml} to train the XGBoost model.")

    # --- New Section for Profit Prediction with RandomForestRegressor ---
    st.header("Stock Price Forecasting for the Next 7 Years (2019-2025)")
    st.markdown(f"Using a **RandomForestRegressor** model, a more advanced and robust model, to predict the closing price trend for {selected_company}.")
    st.markdown("**Note:** This forecast is based on historical patterns and is for demonstration purposes. Future market conditions may vary significantly.")

    def train_and_forecast_rf(df, company_name):
        df_comp = df[df['Name'] == company_name].copy()
        if df_comp.empty or len(df_comp) < 100:  # Need sufficient data points for a good model
            st.warning("Not enough historical data available for forecasting.")
            return None, None

        # Prepare data for RandomForestRegressor
        df_comp['date_ordinal'] = df_comp['date'].apply(lambda x: x.toordinal())
        X = df_comp[['date_ordinal']]
        y = df_comp['close']

        # Split historical data for training and testing to evaluate the model
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Train the RandomForestRegressor model
        model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
        model.fit(X_train, y_train)

        # Evaluate the model on the test set
        y_pred_test = model.predict(X_test)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred_test))
        st.write(f"**Random Forest Model Performance (on historical test data):**")
        st.write(f"**Root Mean Squared Error (RMSE):** {rmse:.2f}")

        # Plot historical performance
        fig_eval, ax_eval = plt.subplots(figsize=(14, 6))
        ax_eval.plot(pd.to_datetime(pd.Series(X_test['date_ordinal']).apply(datetime.date.fromordinal)), y_test, 'o', label='Actual Prices', color='blue', alpha=0.6)
        ax_eval.plot(pd.to_datetime(pd.Series(X_test['date_ordinal']).apply(datetime.date.fromordinal)), y_pred_test, 'o', label='Predicted Prices', color='red', alpha=0.6)
        ax_eval.set_title(f'Random Forest Model Predictions vs Actual Prices on Test Data')
        ax_eval.set_xlabel('Date')
        ax_eval.set_ylabel('Close Price')
        ax_eval.legend()
        ax_eval.grid(True)
        st.pyplot(fig_eval)

        # Generate future dates for prediction (2019 to 2025)
        last_date_historical = df_comp['date'].max()
        future_dates = pd.date_range(start=datetime.date(2019, 1, 1), end=datetime.date(2025, 1, 1))
        future_dates_ordinal = future_dates.to_series().apply(lambda x: x.toordinal()).values.reshape(-1, 1)

        # Predict prices for the future dates
        predicted_prices = model.predict(future_dates_ordinal)

        future_predictions_df = pd.DataFrame({
            'date': future_dates,
            'predicted_close': predicted_prices
        })
        return future_predictions_df, df_comp

    predictions_df, historical_df = train_and_forecast_rf(data_df, selected_company)

    if predictions_df is not None:
        st.subheader(f"Forecasted Price Trend for {selected_company} (2019-2025)")
        fig_forecast, ax_forecast = plt.subplots(figsize=(14, 6))

        # Plot historical data (2013-2018)
        ax_forecast.plot(historical_df['date'], historical_df['close'], label='Historical Close Price (2013-2018)', color='blue')

        # Plot forecasted data (2019-2025)
        ax_forecast.plot(predictions_df['date'], predictions_df['predicted_close'], label='Forecasted Close Price (2019-2025)', color='red', linestyle='--')
        
        ax_forecast.set_title(f'Stock Price Forecast for {selected_company}')
        ax_forecast.set_xlabel('Date')
        ax_forecast.set_ylabel('Price (USD)')
        ax_forecast.legend()
        ax_forecast.grid(True)
        st.pyplot(fig_forecast)

        st.subheader("Predicted Prices for 2019-2025")
        st.write(predictions_df)